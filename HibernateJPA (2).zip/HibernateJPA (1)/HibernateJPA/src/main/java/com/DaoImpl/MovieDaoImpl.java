package com.DaoImpl;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import javax.persistence.TypedQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.HibernateUtil;
import com.Dao.MovieDao;
import com.Entity.Movie;

public class MovieDaoImpl implements MovieDao {
	

	@Override
	public void saveMovie() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction t = session.beginTransaction();
		Scanner s = new Scanner(System.in);
		System.out.println("Create Movie Id :");
		int mid = s.nextInt();
		System.out.println("Create Movie Title :");
		String mname = s.next();
		System.out.println("Create Movie Year Of Release :");
		int mrelease = s.nextInt();
		System.out.println("Create Genre Id :");
		int mgid = s.nextInt();
		Movie m = new Movie();
		m.setId(mgid);
		m.setTitle(mname);
		m.setYear_of_release(mrelease);
		m.setGenre_id(mid);
		session.save(m);
		t.commit();
		System.out.println("Movie record inserted successfully");
		session.close();
		
	}

	@Override
	public void deleteMovie() {
		Session session = HibernateUtil.getSessionFactory().openSession();		
		Scanner s = new Scanner(System.in);
		Transaction t = session.beginTransaction();
		System.out.println("Enter Movie Id :");
		int mid = s.nextInt();
		Movie m1 = session.get(Movie.class,mid);
		session.delete(m1);
		t.commit();
		System.out.println("Movie record deleted successfully");
		session.close();	
	}

	@Override
	public void showMovieById() {
		Session session = HibernateUtil.getSessionFactory().openSession();	
		Scanner s = new Scanner(System.in);
		System.out.println("Enter Movie Id :");
		int mid = s.nextInt();
		Movie m2 = session.get(Movie.class,mid);
		System.out.println("Movie Id :"+m2.getId()+"\n"+"Movie Title :"+m2.getTitle()
		+"\n"+"Movie Year Of Release :"+m2.getYear_of_release()+"\n"+"Movie Genre ID :"+m2.getGenre_id());
		session.close();
		
	}

	@Override
	public void showMovieByName() {
		Session session = HibernateUtil.getSessionFactory().openSession();	
		Scanner s = new Scanner(System.in);
		System.out.println("Enter Movie Title :");
		String mname = s.next();
		Movie m2 = session.get(Movie.class,mname);
		System.out.println("Movie Id :"+m2.getId()+"\n"+"Movie Title :"+m2.getTitle()
		+"\n"+"Movie Year Of Release :"+m2.getYear_of_release()+"\n"+"Movie Genre ID :"+m2.getGenre_id());
		session.close();
	
	}

	@Override
	public List<Movie> getAllMovies() {
		Session session = HibernateUtil.getSessionFactory().openSession();	
		Scanner s = new Scanner(System.in);
		System.out.println("Enter Movie Id :");
		int mid = s.nextInt();
		TypedQuery query = session.getNamedQuery("getAll");
		List<Movie> e = query.getResultList();
		Iterator<Movie> itr = e.iterator();
		while(itr.hasNext()) {
		Movie em = itr.next();	
		Movie m3 = session.get(Movie.class,mid);
		System.out.println("Movie Id :"+m3.getId()+"\n"+"Movie Title :"+m3.getTitle()
		+"\n"+"Movie Year Of Release :"+m3.getYear_of_release()+"\n"+"Movie Genre ID :"+m3.getGenre_id());
		System.out.println(em);
		}
		session.close();
		return e;
	}

}
