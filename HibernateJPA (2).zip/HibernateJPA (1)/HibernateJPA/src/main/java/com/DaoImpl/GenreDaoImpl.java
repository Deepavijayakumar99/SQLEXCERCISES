package com.DaoImpl;

import java.util.Scanner;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.HibernateUtil;
import com.Dao.GenreDao;
import com.Entity.Genre;

public class GenreDaoImpl implements GenreDao {

	@Override
	public void saveGenre() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction t = session.beginTransaction();
		Scanner s = new Scanner(System.in);
		System.out.println("Create Genre Id :");
		int gid = s.nextInt();
		System.out.println("Create Genre Name :");
		String gname = s.next();
		Genre g = new Genre();
		g.setId(gid);
		g.setName(gname);
		session.save(g);
		t.commit();
		System.out.println("Genre record inserted successfully");
		session.close();
	}

}
