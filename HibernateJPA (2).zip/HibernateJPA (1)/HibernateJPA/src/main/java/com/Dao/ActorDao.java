package com.Dao;

public interface ActorDao {
public void saveActor();
public void showActor();
}
