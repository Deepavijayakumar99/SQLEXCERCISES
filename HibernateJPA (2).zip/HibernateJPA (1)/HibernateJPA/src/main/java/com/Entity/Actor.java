package com.Entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Table(name="actors")
@Entity
public class Actor {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private int id;
private String name;
private String last_name;
private int year_of_birth;
@ManyToMany(fetch = FetchType.LAZY,cascade = CascadeType.ALL)
@JoinTable(name="actor_movie",joinColumns = {@JoinColumn(name="id")},inverseJoinColumns = {@JoinColumn(name="id")})
private Set<Movie> movies = new HashSet<>();

public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getLast_name() {
	return last_name;
}
public void setLast_name(String last_name) {
	this.last_name = last_name;
}
public int getYear_of_birth() {
	return year_of_birth;
}
public void setYear_of_birth(int year_of_birth) {
	this.year_of_birth = year_of_birth;
}
public Set<Movie> getMovies() {
	return movies;
}
public void setMovies(Set<Movie> movies) {
	this.movies = movies;
}

}

