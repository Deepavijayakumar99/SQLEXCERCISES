package com.Dao;

import java.util.List;
import com.Entity.Movie;

public interface MovieDao {
public void saveMovie();
public void deleteMovie();
public void showMovieById();
public void showMovieByName();
List<Movie> getAllMovies();
}
