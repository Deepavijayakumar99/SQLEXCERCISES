package com.Entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@NamedNativeQuery(name = "getAll", query = "SELECT * FROM movies", resultClass = Movie.class)
@Table(name="movies")
@Entity
public class Movie {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private int id;
private String title;
private int year_of_release;
private int genre_id;
@ManyToMany(fetch = FetchType.LAZY,cascade = CascadeType.ALL,mappedBy = "movies")
private Set<Actor> actors = new HashSet<>();
@ManyToOne
@JoinColumn(name="id")
private Genre genre;

public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public int getYear_of_release() {
	return year_of_release;
}
public void setYear_of_release(int year_of_release) {
	this.year_of_release = year_of_release;
}
public int getGenre_id() {
	return genre_id;
}
public void setGenre_id(int genre_id) {
	this.genre_id = genre_id;
}
public Set<Actor> getActors() {
	return actors;
}
public void setActors(Set<Actor> actors) {
	this.actors = actors;
}
public Genre getGenre() {
	return genre;
}
public void setGenre(Genre genre) {
	this.genre = genre;
}
   
}

