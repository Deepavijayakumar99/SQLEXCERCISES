package com;

import java.util.Scanner;
import com.DaoImpl.ActorDaoImpl;
import com.DaoImpl.GenreDaoImpl;
import com.DaoImpl.MovieDaoImpl;

public class TestBuild {
public static void main( String[] args ) {
       ActorDaoImpl ad = new ActorDaoImpl();
       GenreDaoImpl gd = new GenreDaoImpl();
       MovieDaoImpl md = new MovieDaoImpl();
       
       while (true) {
    	   
    	Scanner s = new Scanner(System.in);
   		System.out.println("Hibernate Project");
   		System.out.println("Enter Choice");
   		System.out.println(" 1. Actor Details \n 2. Genre Details \n 3. Movie Details \n 4. Exit");
   		int ch = s.nextInt();
   		switch (ch) {
		case 1:
			Scanner s1 = new Scanner(System.in);
	   		System.out.println("Actor Details");
	   		System.out.println("Enter Choice");
	   		System.out.println(" 1. Save Actor \n 2. Show Actor \n 3. Go Back");
	   		int ch1 = s.nextInt();
	   		switch (ch1) {
			case 1:
				ad.saveActor();
				break;
            case 2:
				ad.showActor();
				break;
            case 3:
            	System.out.println("GOING BACK TO MAIN MENU !!!");
				break;
			default:
				System.out.println("WRONG CHOICE OF NUMBER !!! TRY AGAIN !");
				break;
			}
			break;

		case 2:
			Scanner s2 = new Scanner(System.in);
	   		System.out.println("Genre Details");
	   		System.out.println("Enter Choice");
	   		System.out.println(" 1. Save Genre \n 2. Exit");
	   		int ch2 = s.nextInt();
			switch (ch2) {
			case 1:
				gd.saveGenre();
				break;
            case 2:
            	System.out.println("GOING BACK TO MAIN MENU !!!");
				break;

			default:
				System.out.println("WRONG CHOICE OF NUMBER !!! TRY AGAIN !");
				break;
			}
			
			break;

		case 3:
			Scanner s3 = new Scanner(System.in);
	   		System.out.println("Movie Details");
	   		System.out.println("Enter Choice");
	   		System.out.println(" 1. Save Movie \n 2. ShowMoviebyId \n 3. ShowMoviebyName \n 4. GetAllMovies \n 5. DeleteMovie \n 6. Exit");
	   		int ch3 = s.nextInt();
	   		switch (ch3) {
			case 1:
				md.saveMovie();
				break;
            case 2:
				md.showMovieById();
				break;
            case 3:
	            md.showMovieByName();
	            break;
            case 4:
	            md.getAllMovies();
	            break;
            case 5:
	            md.deleteMovie();
	            break;
            case 6:
            	System.out.println("GOING BACK TO MAIN MENU !!!");
	            break;

			default:
				System.out.println("WRONG CHOICE OF NUMBER !!! TRY AGAIN !");
				break;
			}
			break;

		case 4:
	         System.out.println("Thank You !!!");
	         System.exit(0);
			break;

		default:
			System.out.println("WRONG CHOICE OF NUMBER !!! TRY AGAIN !");
			break;
		}
		
	}
	
	
	
    }
}
