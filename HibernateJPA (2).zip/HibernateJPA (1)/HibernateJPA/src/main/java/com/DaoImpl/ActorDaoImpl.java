package com.DaoImpl;

import java.util.Scanner;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.HibernateUtil;
import com.Dao.ActorDao;
import com.Entity.Actor;

public class ActorDaoImpl implements ActorDao {

	@Override
	public void saveActor() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction t = session.beginTransaction();
		Scanner s = new Scanner(System.in);
		System.out.println("Create Actor Id :");
		int aid = s.nextInt();
		System.out.println("Create Actor Name :");
		String aname = s.next();
		System.out.println("Create Actor Last Name :");
		String alname = s.next();
		System.out.println("Create Actor DOB :");
		int adob = s.nextInt();
		Actor a = new Actor();
		a.setId(aid);
		a.setName(alname);
		a.setLast_name(alname);
		a.setYear_of_birth(adob);
		session.save(a);
		t.commit();
		System.out.println("Actor record inserted successfully");
		session.close();
	}

	@Override
	public void showActor() {
		Session session = HibernateUtil.getSessionFactory().openSession();	
		Scanner s = new Scanner(System.in);
		System.out.println("Enter Actor Id :");
		int aid = s.nextInt();
		Actor a1 = session.get(Actor.class,aid);
		System.out.println("Actor ID :"+ a1.getId()+"\n"+"Actor Name :"+a1.getName()+"\n"
		+"Actor Last Name :"+a1.getLast_name()+"\n"+"Actor DOB :"+a1.getYear_of_birth());
		session.close();
	}

}
