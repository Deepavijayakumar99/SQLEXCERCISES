package com.Dao;

public interface GenreDao {
public void saveGenre();

}
